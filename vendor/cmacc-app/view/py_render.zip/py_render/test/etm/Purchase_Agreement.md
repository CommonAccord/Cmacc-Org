Prose Description={Buyer.Name} bought a book for {Buyer.Friend.2.Name}. <br> It was called {Item.Book.Title} by {Item.Book.Author}. She sent it in the mail to {Buyer.Friend.2.Name_and_Address.Formal}.
Item.Book.=[Moby_Dick]
Buyer.=[Alice]
Buyer.Name=Alice
Buyer.Friend.2.Name=Rob