Name=Alice Waters
Friend.2.=[Bob]
City=Providence
State=Rhode Island