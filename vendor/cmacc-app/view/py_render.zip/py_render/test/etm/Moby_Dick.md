Title=Moby Dick
Author=Herman Melville